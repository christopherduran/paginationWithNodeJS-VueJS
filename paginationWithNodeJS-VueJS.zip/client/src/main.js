import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

import axios from 'axios';
import VueAxios from 'vue-axios';

Vue.use(VueAxios, axios);//with that we can make HTTP Requests

new Vue({
  render: function (h) { return h(App) },
}).$mount('#app')
